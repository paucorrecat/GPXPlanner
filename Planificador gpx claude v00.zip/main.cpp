#include <QCoreApplication>
#include <QDebug>
#include "TrackPlanner.h"

/**
 * main.cpp — Exemple d'ús del TrackPlanner
 *
 * En una app Qt amb UI, tot això es faria des de la MainWindow:
 * - Botó "Carregar GPX" → planner.loadGPX(path)
 * - Taula de segments on l'usuari edita potència/vent
 * - Botó "Calcular" → planner.compute()
 * - Botó "Exportar GPX" → planner.exportGPX(outputPath)
 */
int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    // 1. Configura el perfil del ciclista
    RiderProfile rider;
    rider.totalMassKg   = 82.0;   // 75 kg ciclista + 7 kg bici MTB
    rider.ftpWatts      = 220.0;
    rider.cda           = 0.40;   // postura MTB
    rider.crr           = 0.015;  // terra compactat

    // 2. Crea el planificador
    TrackPlanner planner;
    planner.setRiderProfile(rider);
    planner.setStartTime(QDateTime(QDate(2026, 3, 26), QTime(8, 0)));

    // 3. Carrega el GPX
    if (!planner.loadGPX("/ruta/al/track.gpx")) {
        qWarning() << "Error carregant GPX:" << planner.lastError();
        return 1;
    }

    // 4. Defineix trams (índexs de punts GPX)
    //    Exemple: 3 trams. Ajusta els índexs al teu fitxer.
    planner.defineSegments({
        {0,   80},   // Tram 1: sortida fins al primer coll
        {80,  150},  // Tram 2: baixada tècnica
        {150, 220}   // Tram 3: pla final fins a l'arribada
    });

    // 5. Personalitza cada tram
    auto& segs = planner.segments();

    segs[0].label        = "Pujada inicial";
    segs[0].targetPowerW = 180.0;  // esforç sostingut en pujada
    segs[0].windSpeedMs  = 2.0;    // 7 km/h vent de cara

    segs[1].label        = "Baixada tècnica";
    segs[1].targetPowerW = 80.0;   // poca potència, gravitat ajuda
    segs[1].windSpeedMs  = 0.0;

    segs[2].label        = "Pla final";
    segs[2].targetPowerW = 160.0;
    segs[2].windSpeedMs  = -2.0;   // vent de cua (negatiu)

    // 6. Afegeix parades
    planner.addStop({80,  15*60, "Pausa al coll (esmorzar)"});
    planner.addStop({150, 5*60,  "Font d'aigua"});

    // 7. Calcula i mostra el resum
    QString summary = planner.compute();
    qDebug().noquote() << summary;

    // 8. Exporta GPX amb timestamps per al Virtual Partner Garmin
    if (!planner.exportGPX("/ruta/sortida/track_planificat.gpx", "Sortida BTT - La meva ruta")) {
        qWarning() << "Error exportant GPX";
        return 1;
    }

    qDebug() << "GPX exportat correctament!";
    return 0;
}

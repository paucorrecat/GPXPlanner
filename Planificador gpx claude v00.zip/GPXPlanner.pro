QT += core xml
QT -= gui

CONFIG += c++17 console
CONFIG -= app_bundle

TARGET = GPXPlanner

SOURCES += \
    main.cpp

HEADERS += \
    RiderProfile.h \
    TrackPoint.h \
    TrackSegment.h \
    StopPoint.h \
    TimeEstimator.h \
    GPXParser.h \
    TrackPlanner.h

# Per a la versió amb UI, afegiràs:
# QT += widgets
# SOURCES += MainWindow.cpp
# HEADERS += MainWindow.h
# FORMS   += MainWindow.ui
